/**
 * 
 */
/**
 * @author steve
 *
 */
package MyOutputVariableProject;