/**
 * 
 */
/**
 * @author steve
 *
 */
module MyOutputVariableProject {
}